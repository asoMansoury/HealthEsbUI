export const categoryPath = "/products/Categories";
export const usersPath="/users/usersManage";
export const processPath = '/process/processAdd';
export const processListPath = '/process/processList';
export const processEditPath = '/process/processEdit';
export const ProcessPDFPath = '/process/ProcessPDF';

export const PrescriptionBarcodeDetailesPath = "/Prescription/PrescriptionBarcodeDetailes"