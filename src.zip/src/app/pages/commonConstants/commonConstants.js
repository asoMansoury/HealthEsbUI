export const categoryParentCode = '0003';
export const typeMaterialCode= '0002';
export const unitTypeCode = '0001';
export const emplooyerCode = '0004';
export const salaryTypeCode = '0005';
export const ProcessTypeCode = '0006';
export const FlowProcessTypeCode = "0007";
export const CostCategory = "0008";
