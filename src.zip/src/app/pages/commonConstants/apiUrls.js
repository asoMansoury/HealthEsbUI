const APP_URL  = 'https://localhost:44397/api/';

export const GetPrescriptionActivityApi =APP_URL+ 'PrescriptionBarcodeDetailes/GetPrescriptionActivity';