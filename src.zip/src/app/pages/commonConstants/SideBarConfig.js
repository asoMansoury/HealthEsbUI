const SideBarConfi = {
    id : 'sideBarConfig',
    width: 600,
    animationDuration : 100,
};
export default SideBarConfi;